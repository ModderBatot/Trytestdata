'use strict';

/* eslint-disable */
// 使用 es5 写法
(function (window) {
  if (!window.localStorage) return;
  // 尽可能不堵塞主流程异步写入localstroage 是否支持 webp,
  setTimeout(function () {
    if (window.localStorage.getItem('IS_BIGO_SUPPORT_WEBP') === null) {
      var check_webp_feature = function check_webp_feature(feature, callback) {
        var kTestImages = {
          lossy: 'UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA'
        };
        var img = new Image();
        img.onload = function () {
          var result = img.width > 0 && img.height > 0;
          callback(result);
        };
        img.onerror = function () {
          callback(false);
        };
        img.src = 'data:image/webp;base64,' + kTestImages[feature];
      };
      // 是否支持有损webp
      check_webp_feature('lossy', function (res) {
        window.localStorage.setItem('IS_BIGO_SUPPORT_WEBP', res ? '1' : '0');
      });
    }
  }, 1000);
  var isSupportWebp = Number(window.localStorage.getItem('IS_BIGO_SUPPORT_WEBP') || '0');
  function isBase64(str) {
    return /^data:/i.test(str);
  }
  function getConnChar(url) {
    return url.indexOf('?') !== -1 ? '&' : '?';
  }

  // 根据排序，获取支持type 的最小图片
  function getMiniSize(url) {
    // 获取匹配排序标识
    var matchRes = url.match(/\.([wp]{2})\.(png|jpg)$/);
    var sizeMap = {
      w: 21,
      p: 11
    };
    if (matchRes && matchRes[1]) {
      return sizeMap[matchRes[1][0]];
    }
    return;
  }

  // 获取链接参数
  function getUrlParameter(name, isRouterParams) {
    var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
    var search = isRouterParams ? window.location.hash : window.location.search;
    if (isRouterParams) {
      search = window.location.hash.split('?')[1] || '';
    } else {
      search = window.location.search.substr(1);
    }
    var r = search.match(reg);
    if (r != null) {
      return decodeURIComponent(r[2]);
    }
    return '';
  }
  window.bigoMakePicUrl = function (url, _option) {
    if (!url) return url;
    if (!_option) _option = {};
    // 是否全局关闭
    var isClose = getUrlParameter('auto_webp') === '0';
    if (isClose) return url;
    var option = {
      css: false, // 处理 css
      img: false, // 处理 img
      min: true // 是否采用图片最小策略
    };

    if (_option.css !== undefined) {
      option.css = _option.css;
    }
    if (_option.img !== undefined) {
      option.img = _option.img;
    }
    if (_option.min !== undefined) {
      option.min = _option.min;
    }
    if (option.img) {
      if (isBase64(url)) return url;
      if (url.indexOf('resize=') > -1) return url;
      if (isSupportWebp) {
        return url + getConnChar(url) + 'resize=' + ((option.min && getMiniSize(url)) || 21) + '&dw=0';;
      }
      return url;
    }
    if (option.css) {
      if (isSupportWebp) {
        return url.replace(/\.css$/, '.webp.css').replace(/\.css$/, option.min ? '.min.css' : '.css');
      }
      return url;
    }
  };
})(window);